
# https://stackoverflow.com/questions/20822553/align-tabs-from-right-to-left-using-ttk-notebook-widget
# make sure Pillow is installed: the command is "pip3 install Pillow"
# Pillow (previously Photoprocessing Image Library) is used for image handing in Python

import tkinter as tk
from tkinter import ttk
from PIL import ImageTk, Image


#This creates the main window of an application
root = tk.Tk()
root.title("Historical Flags of Canada")
root.minsize(300, 300)
root.geometry("1150x700")

style = ttk.Style()
style.configure('TNotebook', tabposition='nw') #'nw' as in compass direction
# style.configure('lefttab.TNotebook', tabposition='ws')

planner = ttk.Notebook(root, width=1000, height=650)

# Create the frames of different colours that are 200*200 pixels in dimensions

######################################## Start Frame 1 ###################################

tab1 = tk.Frame(planner, bg='red')

#The Label widget is a standard Tkinter widget used to display a text or image on the screen.
#path1 = "flag-intro.jpg"
path1 = "flag-intro.png"

#Creates a Tkinter-label for the picture which can be used everywhere Tkinter expects an image object.
img1 = ImageTk.PhotoImage(Image.open(path1))
pic1 = tk.Label(tab1, image = img1)
pic1.grid(row=1, column=1, padx=5, pady=5)
lbl1 = tk.Label(tab1,text = '*** Strong and Free ***')
lbl1.grid(row = 0, column = 0, columnspan = 4, pady = 5)


######################################## End Frame 1 ###################################


tab2 = tk.Frame(planner, bg='orange')
path2 = "england.png"
img2 = ImageTk.PhotoImage(Image.open(path2))
pic2 = tk.Label(tab2, image = img2)
pic2.grid(row=2, column=2)

tab3 = tk.Frame(planner, bg='yellow')
path3 = "scotland.png"
img3 = ImageTk.PhotoImage(Image.open(path3))
pic3 = tk.Label(tab3, image = img3)
pic3.grid(row=2, column=2)

tab4 = tk.Frame(planner, bg='green')
path4 = "royal-union-1707.png"
img4 = ImageTk.PhotoImage(Image.open(path4).resize((300,200), Image.ANTIALIAS))
pic4 = tk.Label(tab4, image = img4)
pic4.grid(row=2, column=2)


tab5 = tk.Frame(planner, bg='blue')
path5 = "union-jack-1801.jpg"
img5 = ImageTk.PhotoImage(Image.open(path5).resize((300,200), Image.ANTIALIAS))
pic5 = tk.Label(tab5, image = img5)
pic5.grid(row=2, column=2)

tab6 = tk.Frame(planner, bg='indigo')
path6 = "cre-1871.png"
img6 = ImageTk.PhotoImage(Image.open(path6).resize((300,200), Image.ANTIALIAS))
pic6 = tk.Label(tab6, image = img6)
pic6.grid(row=2, column=2)


tab7 = tk.Frame(planner, bg='violet')
path7 = "cre-1957.png"
img7 = ImageTk.PhotoImage(Image.open(path7).resize((300,200), Image.ANTIALIAS))
pic7 = tk.Label(tab7, image = img7)
pic7.grid(row=2, column=2)


# Add the tabs/frames to the notebook object called "planner" 
# Referred to Stack Overflow for assistance

planner.add(tab1, text='Introduction')
planner.add(tab2, text='England')
planner.add(tab3, text='Scotland')
planner.add(tab4, text="Royal Union Flag 1707")
planner.add(tab5, text="Royal Union Flag 1801")
planner.add(tab6, text="Canadian Red Ensign 1871-1921")
planner.add(tab7, text="Canadian Red Ensign 1957-1965")


# Tabs will be added to the "top" of the "frame"
#planner.pack(side=tk.TOP)
planner.grid(row = 0, column = 0)

# Start the GUI
root.mainloop()
